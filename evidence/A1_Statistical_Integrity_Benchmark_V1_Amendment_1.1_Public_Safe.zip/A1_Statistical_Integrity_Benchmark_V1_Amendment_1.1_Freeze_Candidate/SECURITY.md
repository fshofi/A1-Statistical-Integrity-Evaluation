# Security and publication safety

The repository contains no credentials and requires no network access. Do not commit provider API keys, private prompts, account identifiers, or restricted model outputs. Store secrets outside the repository.

Historical frozen execution logs contain generic container paths and runtime metadata as reproducibility provenance. They contain no user home path, credential, token, or session identifier and remain unchanged.

Run `python scripts/security_scan.py` before publication. The scanner detects common credential formats, private-key blocks, user-home paths, and archive path traversal. It is a guardrail, not a guarantee; manual review remains required.
