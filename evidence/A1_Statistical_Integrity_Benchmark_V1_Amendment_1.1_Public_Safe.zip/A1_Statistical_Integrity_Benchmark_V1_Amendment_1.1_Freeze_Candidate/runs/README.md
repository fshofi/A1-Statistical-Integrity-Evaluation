# Model runs - amendment 1.1

Each run uses `runs/<model>/<run_id>/` with:

- immutable `raw_responses.jsonl`;
- mandatory `run_manifest.json` conforming to `schemas/run_manifest.schema.json`;
- derived `derived_parsing_and_scores.jsonl` and `summary.json`;
- optional response-bound `semantic_reviews.jsonl` conforming to `schemas/semantic_review.schema.json`;
- separate adjudication records and agreement report when multiple reviewers are used.

Use `run_manifest.example.json` as a field checklist, then replace every placeholder. Unavailable settings must be the exact sentinel `UNAVAILABLE / NOT EXPOSED`, never guessed and never null.

Run 0 is external/not supplied in this workspace and must not be scored or reconstructed. See `docs/RUN0_STATUS.md`.
