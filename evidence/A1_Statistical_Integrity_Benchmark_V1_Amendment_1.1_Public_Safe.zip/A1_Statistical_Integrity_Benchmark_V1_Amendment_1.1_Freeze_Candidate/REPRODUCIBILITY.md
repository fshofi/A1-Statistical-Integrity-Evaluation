# Reproducibility

## Requirements

- Python 3.10 or newer
- No third-party runtime dependencies

## Verify and test

From the repository root:

```bash
python -m pip install --no-index -r requirements.txt
python scripts/verify_hashes.py
python -m unittest discover -s tests -v
python scripts/clean_replay.py --log results/clean_replay.log
```

The hardened clean replay first reads the frozen expected bytes, copies the bundle
to a temporary directory, deletes the copied output, confirms it does not exist,
and only then executes Rev-2. Success requires exit code zero, a newly created
output file, reported expected/generated hashes, identical parsed records, and
identical bytes after CRLF/LF normalization. A successful checker process that
writes nothing fails regression testing. The repository baseline is never
overwritten.

`results/execution_log.txt` records the publication-gate run. Paths in committed
logs are repository-relative or redacted; no external data file is required.
