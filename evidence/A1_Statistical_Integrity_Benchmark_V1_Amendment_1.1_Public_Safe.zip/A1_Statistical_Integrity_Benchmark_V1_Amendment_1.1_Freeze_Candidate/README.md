# A1 — Statistical Integrity Benchmark for LLMs

**Status:** V1 publication candidate with a validated Rev-2 reference checker and benchmark framework.

**Protocol amendment:** H01-H06 repairs and IV-01-IV-05 final reconciliation are implemented in amendment 1.1. The Rev-2 reference layer is unchanged. Run 0 is `EXTERNAL / NOT SUPPLIED`; its hashes are not claimed verified and rescoring is blocked. The verification suite comprises 24 formal H01-H06 unit tests plus 8 supplemental integration/artifact/replay checks (32 discovered methods total).

A1 evaluates whether a language model can reason responsibly about compact statistical and data-science scenarios. It checks more than final-answer accuracy: a numerically correct result may still rely on leakage, confounding, an invalid method, a hidden assumption, or a conclusion that exceeds the evidence.

## What it tests

The 24 public cases cover sampling and dependence, observational and causal claims, predictive evaluation, temporal leakage, diagnostic metrics, class imbalance, multiplicity, uncertainty, optimisation, and model interpretation. Evaluation is localised along this spine:

`Evidence → Assumptions → Method → Reasoning → Uncertainty → Validity → Conclusion`

Numeric fields can be compared deterministically. The seven semantic dimensions use a transparent 0–2 rubric and require human review (or a separately validated semantic grader). A total is never reported without dimension scores and failure labels.

## What is original and frozen

Shofi Ahmed Uddin defined the project, statistical judgement, evaluation design, architecture decisions, validation criteria, and final sign-off. The complete validated Rev-2 bundle is preserved byte-for-byte under `baseline/a1_revision_bundle/`, including 24 public cases and answers, original blind-run artifacts, both revisions, execution logs, change history, and the frozen-content SHA-256 manifest.

The incoming repository manifest is preserved as `baseline/FREEZE_CANDIDATE_PROJECT_SHA256.txt`. `PROJECT_SHA256.txt` covers this publication build. No validated numerical value or reference answer was changed.

## Quick start

Requires Python 3.10+; runtime and tests use only the standard library.

```bash
python -m pip install --no-index -r requirements.txt
python scripts/verify_hashes.py
python -m unittest discover -s tests -v
python scripts/clean_replay.py --log results/clean_replay.log
```

The clean replay runs the checker from a temporary copy and requires identical parsed records and identical bytes after newline normalization. It never overwrites the repository baseline. Raw bytes may differ only because Windows text mode emits CRLF while the frozen Linux artifact uses LF; this is reported explicitly.

## First model run

1. Start a fresh model context and provide only `scenario`, `data`, and `task` from `data/cases.jsonl`.
2. Save every raw response verbatim as JSONL: `{"case_id":"Q142","response": ...}`.
3. Record model/version, UTC time, sampling settings, and governing instructions in `runs/<model>/<run_id>/metadata.json`.
4. After generation, optionally add reviewed 0–2 dimension scores using `runs/example_run/reviews.example.jsonl`.
5. Run:

```bash
python scripts/run_benchmark.py runs/<model>/<run_id>/raw_responses.jsonl \
  --run-manifest runs/<model>/<run_id>/run_manifest.json \
  --reviews runs/<model>/<run_id>/semantic_reviews.jsonl \
  --output-dir runs/<model>/<run_id>
```

Omit `--reviews` to produce only amended parsing and deterministic numeric results while marking semantic dimensions for review. See `docs/SCORING_SPECIFICATION.md`, `docs/SEMANTIC_REVIEW_PROTOCOL.md`, and `docs/RUN_PROTOCOL_AMENDMENT_H01_H06.md`.

## Repository map

- `baseline/` — immutable reference provenance and manifests
- `data/` — exact public case mirror
- `src/` — loaders, validation, numeric comparison, and scoring
- `scripts/` — run, replay, hash, manifest, and security tools
- `tests/` — integrity, scoring, and end-to-end replay tests
- `runs/` — model-run protocol and non-result templates
- `docs/` — architecture, scope, methodology, taxonomy, and run protocol
- `results/` — reproducibility and publication-gate evidence

## Validation boundary

Validated: frozen manifests, 24/24 loading and ID alignment, Rev-2 clean replay, numeric preservation, publication tests, and model-run plumbing behavior.

Not yet validated: cross-model performance, inter-rater reliability, a semantic auto-grader, leaderboard stability, or universal coverage of statistical reasoning. A single 24-case run is descriptive, not a proven stable ranking.

See [methodology](docs/METHODOLOGY.md), [reproducibility](REPRODUCIBILITY.md), [limitations](LIMITATIONS.md), and [AI disclosure](AI_ASSISTANCE_DISCLOSURE.md).

## License

Code and original repository materials are released under the MIT License. Users remain responsible for any model-provider terms applying to outputs they add later.
