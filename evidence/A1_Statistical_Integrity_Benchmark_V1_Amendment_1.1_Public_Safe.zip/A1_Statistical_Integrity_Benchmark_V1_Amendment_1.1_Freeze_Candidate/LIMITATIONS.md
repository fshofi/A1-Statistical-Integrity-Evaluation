# Limitations

- The benchmark has 24 cases and cannot represent all statistical practice.
- The validated baseline is a reference checker, not a universally validated ontology.
- Qualitative fields require rubric-based or human review; automated semantic grading has not been validated.
- Inter-rater reproducibility has not yet been established for public model comparisons.
- A single run is sensitive to model version, prompting, sampling settings, and provider behavior.
- Public cases may eventually enter training corpora; contamination must be considered in later results.
- Correct final numbers can coexist with invalid methods or conclusions, and the reverse can occur for partial work.
- Benchmark performance should not be interpreted as professional competence or scientific reliability outside scope.
