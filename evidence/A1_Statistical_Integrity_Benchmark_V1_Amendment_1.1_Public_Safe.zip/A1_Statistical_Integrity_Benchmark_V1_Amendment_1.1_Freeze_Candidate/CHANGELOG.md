# Changelog

## 1.1.1 - IV-01 through IV-05 final reconciliation

- Identified `fa5a...` as the corrected Rev-2 answer file and `b9c5...` as the distinct original blind answer file; added fresh hash evidence.
- Classified 32 discovered methods as 24 formal H01-H06 unit tests plus 8 supplemental integration/artifact/replay checks.
- Confirmed and documented the active `0.0000005` (`0.5 x 10^-6`) tolerance; removed an unused legacy comparison helper to eliminate ambiguity.
- Confirmed explicit safe unit aliases in policy/code/tests.
- Confirmed the exact `UNAVAILABLE / NOT EXPOSED` sentinel in JSON Schema, runtime validation, and tests.
- Added a machine-verified test inventory and this reconciliation record.
- Made the supplemental clean-replay test force UTF-8 for its subprocess output,
  eliminating a Windows `cp1252` decoding failure found during final ZIP replay.
- Preserved the pre-reconciliation project manifest as
  `baseline/PRE_RECONCILIATION_PROJECT_SHA256.txt` before regenerating the root
  freeze-candidate manifest.

No frozen reference, validated numeric value, benchmark case, or Rev-2 checker was changed.

## 1.1.0 - H01-H06 scoring/run-protocol amendment

- Separated requested numeric fields from supplemental reference quantities; Q731 `coverage_narrow` is not required.
- Frozen prompt-authorized six-decimal and exact-integer numeric policies.
- Added duplicate-safe JSON/JSON-like/plain-number parsing and independent unit/value/math states.
- Separated completeness, applicability, parsing, correctness, and explicit denominators.
- Added mandatory run-manifest and response-bound semantic-review schemas.
- Hardened clean replay by deleting copied output and requiring a newly generated file.
- Added H01-H06 and no-write replay regression tests.
- Marked Run 0 `EXTERNAL / NOT SUPPLIED`; no reconstruction, verification claim, or scoring performed.
- Recorded Q142, Q216, Q731, and Q976 prose challenges as pending statistical adjudication.
- Preserved the pre-amendment publication manifest as
  `baseline/PRE_AMENDMENT_PROJECT_SHA256.txt`; the root manifest is regenerated
  for amendment 1.1.

No frozen case, answer, numeric value, checker, or provenance artifact changed.

## 1.0.0 — publication integration

- Preserved the validated Rev-2 bundle byte-for-byte under its original path.
- Preserved the incoming project manifest as `baseline/FREEZE_CANDIDATE_PROJECT_SHA256.txt`.
- Added an exact public case mirror and a drift test.
- Added dependency-free loaders, validators, numeric comparison, rubric ingestion, failure labels, and exports.
- Added clean replay, hash verification, unit/integration tests, and publication/security documentation.
- Added run templates without fabricated model outputs or scores.
- Added an MIT license and packaging metadata.
- Documented the independently reproduced Windows CRLF/Linux LF checker-output
  difference; parsed records and newline-normalized bytes are identical.

The statistical change history and SC-01–SC-07/R2 records remain in
`baseline/a1_revision_bundle/CHANGE_LOG.md`. No frozen numerical value or
reference answer was changed by this publication integration.
