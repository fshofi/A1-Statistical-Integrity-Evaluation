# Amendment 1.1 public-safe derivative

This directory is a publication-safe derivative of the canonical private Amendment 1.1 freeze artifact.

- HISTORICAL PRIVATE FREEZE SHA-256: `01e7092db82c1d3750ecc88fcb3fb12cc89436ef31584322987f35e878602d75`
- Publication transformation: local path identifiers redacted; non-source compiled caches excluded if present.
- Benchmark cases, raw references, numeric values, checker/parser/scoring logic, schemas, and tests were not changed.
- The original private archive remains unchanged and is not included here.
- The root `PROJECT_SHA256.txt` is a new manifest for this derivative. The original private manifest is preserved as `baseline/HISTORICAL_PRIVATE_FREEZE_PROJECT_SHA256.txt` for provenance only and is not a manifest for this derivative.

The public-safe archive has its own externally recorded SHA-256 and must not be represented as the historically frozen ZIP.
