# H01-H06 scoring and run-protocol amendment

| Finding | Previous defect | Repair implemented | Test evidence | Status |
|---|---|---|---|---|
| H01 | Supplemental Q731 coverage could be required. | Frozen 24-case requested/supplemental mapping; supplemental fields excluded from completeness. | `test_q731_requested_fields_only_passes` | REPAIRED |
| H02 | Hidden tolerance rejected prompt-valid rounding. | Six-decimal half-unit absolute tolerance and exact-integer policy frozen in JSON. | exact, rounded, and incorrect-nearby tests | REPAIRED |
| H03 | Units, formatting, math, and duplicate keys were conflated. | Separate parser states, canonical aliases, incompatible units, preserved submitted unit, duplicate rejection. | canonical/alias/incompatible, JSON, JSON-like, number, duplicate, malformed tests | REPAIRED |
| H04 | Empty nonnumeric responses could count as numeric PASS. | Completeness, applicability, parsing, and correctness separated; explicit denominators. | Q187/Q542/Q639/Q976 plus summary test | REPAIRED |
| H05 | Run context was incompletely frozen. | Mandatory manifest schema and runtime validator with `UNAVAILABLE / NOT EXPOSED`. | valid/missing/null manifest tests | REPAIRED |
| H06 | Semantic scores lacked response/reviewer binding. | Per-dimension response-hash-bound review schema and adjudication protocol. | binding, provenance, rationale/rubric tests | REPAIRED |
| Replay | Copied expected output could mask no-write execution. | Copied output is deleted before execution; existence, exit, hashes, and semantic identity are independently required. | real checker and successful no-write checker tests | REPAIRED |

No benchmark case, frozen answer, validated numeric value, or Rev-2 checker source was changed.

Test-count reconciliation: 24 formal H01-H06 unit tests plus 8 supplemental integration/artifact/replay checks equal 32 discovered unittest methods. The total is not described as 32 formal unit tests.
