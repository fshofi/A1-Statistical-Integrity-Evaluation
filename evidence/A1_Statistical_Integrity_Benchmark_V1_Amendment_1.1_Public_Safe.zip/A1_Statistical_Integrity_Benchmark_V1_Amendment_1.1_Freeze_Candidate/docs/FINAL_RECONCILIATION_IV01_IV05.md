# Amendment 1.1 final reconciliation - IV-01 through IV-05

## IV-01 - hash reconciliation

`fa5af07dde36625f21b64a776f4e11b78eb7f19859105adff6d2a2875ad921f7` is the SHA-256 of:

`baseline/a1_revision_bundle/revision/checker_answers_rev2.jsonl`

`b9c55dbf0386050f70f05ae0dea0370b9c1b71ff193af6f881bcee5fc48ca31c` is the SHA-256 of the distinct earlier file:

`baseline/a1_revision_bundle/originals/checker_answers.jsonl`

They differ because the first is the corrected Rev-2 answer distribution and the second is the preserved original blind output. Both belong in provenance; `fa5a...` is the applicable Rev-2 corrected distribution. `results/IV01_HASH_EVIDENCE.txt` is freshly generated independent evidence. The earlier documentation identifying `fa5a...` as the frozen Rev-2 answer hash was correct; any interpretation that `b9c5...` was the Rev-2 file is explicitly corrected here.

## IV-02 - test count

The suite contains exactly:

- **24 formal H01-H06 unit tests**;
- **8 supplemental integration, artifact-identity, denominator, and replay regression checks**;
- **32 discovered unittest methods in total**.

The 32 total must not be described as 32 formal unit tests. `config/test_inventory_v1.json` lists every method and `scripts/verify_test_inventory.py` checks discovery against the frozen 24+8 classification.

## IV-03 - tolerance

The active amended scoring path reads `absolute_tolerance: 0.0000005` from `config/scoring_policy_v1.json`, equal to `0.5 x 10^-6`. `src/parsing.py::numeric_status` applies that value. No active or inactive `1 x 10^-6` acceptance tolerance exists in this freeze candidate. An unused legacy structural comparison helper with a different `1 x 10^-12` default was removed to leave one authoritative path. Frozen case values are unchanged.

## IV-04 - unit aliases

Safe aliases are implemented in `config/scoring_policy_v1.json`, normalized and checked by `src/parsing.py::unit_status`, and covered by canonical, equivalent-alias, incompatible-unit, and submitted-unit-preservation tests. Percent is intentionally not an alias for a 0-to-1 proportion because it requires numeric rescaling.

## IV-05 - unavailable settings

`UNAVAILABLE / NOT EXPOSED` is the required sentinel in both `schemas/run_manifest.schema.json` and `src/schemas.py`. Temperature and top-p accept only numeric exposed values or that exact sentinel; maximum output tokens accepts a positive integer or the sentinel. Null and vague strings such as `unknown` fail tests.

## Freeze conclusion

All five independent-verification findings are reconciled without changing benchmark cases, validated numeric values, frozen reference answers, or the Rev-2 checker.
