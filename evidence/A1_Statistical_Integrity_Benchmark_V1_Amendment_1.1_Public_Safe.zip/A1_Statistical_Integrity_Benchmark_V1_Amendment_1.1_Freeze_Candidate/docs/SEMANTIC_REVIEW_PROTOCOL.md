# Semantic review protocol - amendment 1.1

The seven dimensions - evidence, assumptions, method, reasoning, uncertainty, validity, and conclusion - are candidate review dimensions, not validated psychometric constructs.

Each JSONL record represents one reviewer decision on one dimension and must bind to run ID, case ID, exact raw-response SHA-256, reviewer identity or controlled role, reviewer system/model, UTC timestamp, rubric version, score, rationale, optional confidence, and adjudication status.

## Allowed scores

- `0`: materially wrong, absent, or invalid for the dimension.
- `1`: partly correct but materially incomplete, ambiguous, or overclaimed.
- `2`: correct and sufficiently qualified for the case.

Missing review means missing evidence; it is never converted to zero. Confidence is optional and, when used, is a number from 0 to 1. It does not change the score automatically.

## Calibration

Before live review, reviewers independently score a designated calibration subset, compare their interpretations of the rubric, record clarifications without changing case answers, and freeze the clarified rubric version. Calibration cases must not be used to force agreement on later cases.

## Disagreement and adjudication

Retain every reviewer record. Never average silently and never overwrite a dissenting decision. Represent unresolved differences with `DISAGREEMENT_UNRESOLVED`. An adjudicator reviews the response, reference evidence, both rationales, and rubric; the adjudication is a new bound record with status `ADJUDICATED`, not a rewrite. Forced consensus is prohibited.

## Inter-rater agreement

Report raw exact agreement and a chance-corrected ordinal statistic where feasible (recommended: quadratic-weighted Cohen's kappa for two reviewers, Krippendorff's alpha with ordinal distance for more/general missingness). Report per dimension, sample size, missingness, confidence interval or resampling method where used, and the adjudication timing. Calculate pre-adjudication agreement; post-adjudication agreement is not an independence measure.
