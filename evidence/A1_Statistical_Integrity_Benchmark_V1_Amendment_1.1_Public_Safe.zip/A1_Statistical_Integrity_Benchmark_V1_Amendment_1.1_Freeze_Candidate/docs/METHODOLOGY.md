# Methodology

## Research question and unit

A1 asks whether an LLM can calculate, diagnose, qualify, and repair material statistical defects in compact data-science scenarios. Each case contains an ID, scenario, optional structured data, and task. The frozen reference provides numeric values, derivation, assumptions, uncertainty, conclusion, minimum repair, execution status, and ambiguities.

## Reference governance

The baseline evolved through a blind checker run, targeted semantic review, Rev-1 repair, independent review, and Rev-2 targeted repair. Original and revised artifacts, logs, decisions, and hashes are retained. Code generation alone is not treated as validation. Publication tooling reads the frozen baseline and never silently regenerates it.

## Evaluation dimensions

1. **Evidence** — identifies the observations/design and respects their boundary.
2. **Assumptions** — surfaces assumptions needed for calculation or inference.
3. **Method** — selects and applies a procedure appropriate to the task.
4. **Reasoning** — connects evidence, calculations, and claims consistently.
5. **Uncertainty** — qualifies uncertainty without confusing variance, bias, and identification.
6. **Validity** — respects causal, predictive, temporal, sampling, and evaluation validity.
7. **Conclusion** — states an admissible conclusion and, when required, a minimum repair.

Rubric: `0` materially wrong/missing; `1` partly correct but incomplete or overclaimed; `2` correct and sufficiently qualified. Review notes should explain material 0/1 decisions. Report dimension scores alongside any sum.

## Deterministic boundary

`src/scoring.py` recursively compares structured numeric fields using documented absolute and relative tolerances. It does not infer semantic correctness from word overlap. Free text remains `requires_human_review` until a review record is supplied.

## Leakage control

During generation, supply only public `scenario`, `data`, and `task`. Never expose reference answers, checker code, revision notes, taxonomy mappings, previous responses, or scores. Save raw responses before opening the evaluation layer.

## Comparison claims

One 24-case run may be summarized descriptively. Broader claims require a preregistered protocol, repeated runs where stochasticity is material, documented model/version/settings, controlled review, and inter-rater assessment.
