# Architecture

```text
public cases → model generation → raw response JSONL → parse
                                                    ↓
frozen Rev-2 reference ─────────────────────→ compare numeric fields
human rubric ───────────────────────────────→ score semantic dimensions
                                                    ↓
                                      localise failures → export
```

The frozen layer under `baseline/a1_revision_bundle/` is evidence, not working
state. Publication code reads it but does not regenerate it. `data/cases.jsonl`
is an exact public mirror guarded by tests. Model responses remain separate in
`runs/`. Amendment 1.1 inserts an immutable-raw/derived-parser boundary, applies
the explicit requested-field and numeric policy in `config/`, and exports each
parse/unit/value/applicability state independently. Evidence, assumptions,
method, reasoning, uncertainty, validity, and conclusion require separately
stored, response-hash-bound review records.
