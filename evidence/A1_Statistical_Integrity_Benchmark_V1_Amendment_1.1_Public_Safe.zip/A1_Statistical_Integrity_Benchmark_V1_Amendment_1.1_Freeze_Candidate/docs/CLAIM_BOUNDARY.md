# Prior-art and publication claim boundary

## Supported at this stage

- a specified set of 24 cases;
- 12 matched contrasts;
- a reproducible Rev-2 reference checker;
- a controlled-response-collection protocol (with Run 0 external/not supplied in this workspace);
- a repair-oriented statistical-integrity evaluation framework.

## Unsupported at this stage

- benchmark superiority;
- broad population-level model competence;
- universal statistical-reasoning coverage;
- a stable leaderboard ranking;
- validated seven-factor measurement;
- causal localisation of internal model reasoning;
- iid population inference from 24 selected prompts.

Prior-art findings do not alter benchmark cases or frozen reference content in this amendment.
