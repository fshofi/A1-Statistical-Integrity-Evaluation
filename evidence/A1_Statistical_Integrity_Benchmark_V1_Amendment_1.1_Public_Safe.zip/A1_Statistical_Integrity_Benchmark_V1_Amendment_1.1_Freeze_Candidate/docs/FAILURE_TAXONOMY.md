# Failure taxonomy — V1 candidate

This is a descriptive, benchmark-specific vocabulary, not a validated universal ontology. Reviewers may assign more than one code, but should identify the defect that most changes the admissible conclusion.

| Code | Failure class | Public meaning |
|---|---|---|
| `N` | Numerical error | A calculation, unit, scale, or statistical quantity is wrong. |
| `E` | Evidence-boundary failure | The claim goes beyond what the stated evidence supports. |
| `A` | Hidden assumption | A necessary modelling or sampling assumption is unstated or unjustified. |
| `C` | Confounding / causal overreach | Association is treated as causal without identification support. |
| `U` | Uncertainty misstatement | Uncertainty is missing, unjustified, or confused with bias/identification. |
| `R` | Internal contradiction | Evidence, derivation, assumptions, or conclusion conflict. |
| `M` | Invalid method / metric misuse | The procedure or metric is inappropriate for the task. |
| `L` | Leakage | Evaluation uses information unavailable at the decision boundary. |
| `V` | Validity failure | A causal, predictive, sampling, or evaluation validity boundary is broken. |
| `VC` | Valid calculation / invalid conclusion | Arithmetic is correct but the inference drawn from it is not. |
| `X` | Minimum-repair failure | The repair does not remove the defect or improperly changes the task. |

## Materiality and minimum repair

The primary label should identify the issue that most changes what may safely be concluded. Secondary labels remain useful. A minimum repair is the smallest change that restores a valid inference or evaluation while preserving the stated operational task.
