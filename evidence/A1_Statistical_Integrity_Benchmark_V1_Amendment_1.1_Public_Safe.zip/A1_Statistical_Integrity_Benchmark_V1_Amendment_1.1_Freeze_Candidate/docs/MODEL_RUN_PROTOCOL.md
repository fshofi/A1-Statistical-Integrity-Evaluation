# Model run protocol - V1 amendment 1.1

## Pre-run freeze

Before generation, freeze `schemas/run_manifest.schema.json`, the exact user prompt template, exact 24-case payload, execution order, retry/timeout/truncation/refusal handling, source repository hash, and case-set hash. Record every required field. Use the literal `UNAVAILABLE / NOT EXPOSED` for an unavailable setting; never use an invented value or null.

## Generation controls

1. Use a fresh context per case unless a different method was frozen and justified.
2. Supply only public scenario, data, and task plus the exact neutral prompt template.
3. Do not expose checker code, reference answers, revision notes, taxonomy, rubric, or previous answers.
4. Save each raw response verbatim before parsing or review.
5. Record refusals, provider errors, truncation, timeouts, and retries rather than dropping cases.
6. Do not change settings silently between cases.

## Mandatory manifest

The manifest records provider/model/version/runtime/reasoning, UTC bounds, exact prompts and payloads, exposed system/developer prompts and sampling controls, all access surfaces, isolation, order, failure policies, collector version, and source/case/raw hashes. Validate it before parsing with `src.schemas.validate_run_manifest`.

## Derived processing

Raw response storage and derived parsing are separate files. Run:

```bash
python scripts/run_benchmark.py raw_responses.jsonl \
  --run-manifest run_manifest.json \
  --output-dir derived/
```

Add `--reviews semantic_reviews.jsonl` only for records conforming to the response-bound review schema. Missing/unparsed output is not mathematically wrong; non-applicable numeric cases are excluded from numeric denominators; semantic review is never silently aggregated.

## Publication

Preserve raw generation, derived parsing, semantic decisions, adjudication, and summary separately. Report denominators and missingness. A single 24-case run is descriptive and cannot establish a stable leaderboard or population-level competence.
