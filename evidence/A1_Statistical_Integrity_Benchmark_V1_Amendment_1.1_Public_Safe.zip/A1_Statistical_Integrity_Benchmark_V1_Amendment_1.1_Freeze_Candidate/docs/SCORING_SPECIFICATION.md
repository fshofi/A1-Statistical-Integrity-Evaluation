# Scoring specification - amendment 1.1

This specification freezes H01-H04 rules before any model performance is examined. Reference truth, parsing, deterministic scoring, semantic review, run protocol, and publication claims are separate layers.

## Requested and supplemental quantities

`config/scoring_policy_v1.json` is the auditable task-to-field mapping for all 24 cases. `required_numeric_fields` alone determines completeness. `supplemental_numeric_fields` may exist in the frozen reference but cannot cause an omission failure. For Q731, `nominal_lower` and `nominal_upper` are required; `coverage_narrow` is supplemental and remains unchanged in Rev-2.

## Numeric acceptance

Noninteger tasks request at least six decimal places. The sole active amended policy is `absolute_error <= 0.5 * 10^-6` (plus a machine-scale comparison epsilon), stored as `absolute_tolerance: 0.0000005`. Relative tolerance is zero. `src/parsing.py::numeric_status` reads and applies this policy. No `1 * 10^-6` tolerance is implemented. This accepts the correctly rounded Q195 value `0.005510` while rejecting materially different nearby values. Count fields use exact-integer equality. The full-precision frozen reference is never rounded or replaced.

## Derived parsing states

Raw responses are immutable inputs. `src/parsing.py` derives:

- `response_present`: PASS or FAIL;
- `parse_status`: structured object, valid JSON, valid supported JSON-like text, plain-text number, duplicate keys, unparsed, or empty;
- `required_fields_present`: PASS, FAIL, or NOT_APPLICABLE;
- `unit_status`: CANONICAL, EQUIVALENT_ALIAS, MISSING, INCOMPATIBLE, or NOT_APPLICABLE;
- `numeric_value_status`: PASS, FAIL, missing/invalid, or NOT_APPLICABLE;
- `mathematical_correctness`: PASS, FAIL, NOT_EVALUATED, or NOT_APPLICABLE.

UNPARSED is not mathematically wrong. A missing unit is reported separately from numeric correctness. Duplicate JSON and JSON-like keys are rejected rather than resolved by last-key wins.

## Applicability and denominators

An empty response always fails response completeness. Cases Q187, Q542, Q639, and Q976 have no numeric target and return `numeric_applicability=NOT_APPLICABLE`; this never counts as numeric PASS. Reports include:

- total response denominator (24);
- numeric-applicable denominator (20 cases);
- numeric-evaluated denominator (only applicable cases reaching PASS/FAIL);
- unevaluated-applicable count;
- non-applicable count.

## Semantic boundary

Deterministic output never supplies seven-dimension scores. Semantic decisions are separate response-bound records governed by `schemas/semantic_review.schema.json` and `docs/SEMANTIC_REVIEW_PROTOCOL.md`.
