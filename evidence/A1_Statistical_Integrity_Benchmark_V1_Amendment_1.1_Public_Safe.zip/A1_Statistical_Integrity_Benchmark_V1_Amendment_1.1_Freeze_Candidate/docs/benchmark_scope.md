# Benchmark scope

A1 contains 24 compact statistical and data-science cases. It tests whether a
response respects evidence boundaries while calculating, selecting methods,
reasoning about uncertainty, and proposing a minimum repair.

The domains represented include sampling and dependence, causal inference,
observational comparisons, predictive evaluation and leakage, diagnostic
metrics, class imbalance, multiplicity, uncertainty estimation, optimisation,
and interpretation of model performance.

The validated object is the Rev-2 reference checker and benchmark framework.
A1 is not a proven universal benchmark, a psychometric instrument, or evidence
that one 24-case score is a stable estimate of general model capability.
