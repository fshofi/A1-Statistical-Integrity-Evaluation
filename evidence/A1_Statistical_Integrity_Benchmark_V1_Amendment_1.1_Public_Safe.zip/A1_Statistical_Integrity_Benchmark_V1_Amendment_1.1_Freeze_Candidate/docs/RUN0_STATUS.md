# Run 0 preservation status

**Designation:** RUN 0 - PRE-AMENDMENT CONTROLLED COLLECTION

**Workspace state:** EXTERNAL / NOT SUPPLIED

The authentic Run 0 evidence package is not present in this repository or amendment workspace. Therefore:

- no Run 0 response is recreated, inferred, regenerated, substituted, or scored;
- no Run 0 prompt, timestamp, metadata, or response hash is claimed verified;
- no replacement model collection is performed;
- Run 0 rescoring remains **BLOCKED** until the authentic evidence package is supplied.

After supply, verify its original manifest and raw-response hashes before processing. Any amended scoring must disclose: `RESPONSES WERE COLLECTED BEFORE THE SCORING/PROTOCOL AMENDMENT.`
